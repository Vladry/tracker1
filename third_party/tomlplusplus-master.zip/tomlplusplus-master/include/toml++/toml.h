// this file is just for backwards compatibility.
#ifndef TOMLPLUSPLUS_H
#define TOMLPLUSPLUS_H

#include "toml.hpp"

#endif
