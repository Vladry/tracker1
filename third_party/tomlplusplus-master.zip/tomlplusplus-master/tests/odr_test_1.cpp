#define TOML_UNDEF_MACROS 0
#include "../toml.hpp"

TOML_DISABLE_WARNINGS;

int main()
{
	return 0;
}
