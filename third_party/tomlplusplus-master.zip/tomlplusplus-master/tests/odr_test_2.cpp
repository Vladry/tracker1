#include "../toml.hpp"
#include "../toml.hpp" // make sure it behaves if included more than once
